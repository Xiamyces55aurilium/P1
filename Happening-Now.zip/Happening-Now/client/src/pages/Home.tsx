import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import LegalAssistant from "@/components/chat/LegalAssistant";
import CategoryCards from "@/components/categories/CategoryCards";
import LocalHelpMap from "@/components/map/LocalHelpMap";
import { useLanguage } from "@/lib/LanguageContext";
import { Scale } from "lucide-react";

export default function Home() {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen flex flex-col flex-grow bg-background font-sans overflow-x-hidden">
      <Navbar />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative pt-20 pb-28 px-4 sm:px-6 lg:px-8 overflow-hidden">
          {/* Background Decorative Elements */}
          <div className="absolute top-0 inset-x-0 h-full bg-gradient-to-b from-primary/5 to-transparent pointer-events-none -z-10" />
          <div className="absolute -top-40 -right-40 w-[600px] h-[600px] rounded-full bg-accent/5 blur-3xl pointer-events-none -z-10" />
          <div className="absolute top-40 -left-20 w-[400px] h-[400px] rounded-full bg-primary/5 blur-3xl pointer-events-none -z-10" />
          
          <div className="max-w-4xl mx-auto text-center mb-16 relative">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 text-accent-foreground font-semibold text-sm mb-6 border border-accent/20">
              <Scale className="w-4 h-4 text-accent" />
              <span className="text-accent tracking-wide uppercase">AI Legal Assistant</span>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-7xl font-display font-bold text-foreground leading-tight mb-6">
              {t("heroTitle")}
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-2xl mx-auto">
              {t("heroSubtitle")}
            </p>
          </div>

          {/* Main Interactive Component */}
          <LegalAssistant />
        </section>

        {/* Categories Section */}
        <div className="bg-white">
          <CategoryCards />
        </div>

        {/* Local Help Map Section */}
        <LocalHelpMap />
      </main>

      <Footer />
    </div>
  );
}
