import React, { createContext, useContext, useState, ReactNode } from "react";

type Language = "en" | "hi";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: keyof typeof translations["en"]) => string;
}

const translations = {
  en: {
    appName: "Rights Navigator",
    heroTitle: "Know Your Rights. Protect Yourself.",
    heroSubtitle: "Describe your situation in plain language, and our AI will help you understand your legal rights and the steps you can take.",
    inputPlaceholder: "E.g., My landlord is refusing to return my security deposit after I moved out...",
    analyzeButton: "Analyze My Situation",
    analyzing: "Analyzing...",
    categoryTitle: "Legal Category",
    explanationTitle: "Simple Explanation",
    stepsTitle: "Actionable Steps",
    commonCategories: "Common Legal Issues",
    localHelp: "Find Local Legal Aid",
    localHelpDesc: "Free and low-cost legal clinics available in your area.",
    consumerRights: "Consumer Rights",
    workerRights: "Worker Rights",
    womensRights: "Women's Rights",
    tenantRights: "Tenant Rights",
    digitalFraud: "Digital Fraud",
    footerText: "A civic technology initiative. Not formal legal advice.",
  },
  hi: {
    appName: "अधिकार नेविगेटर",
    heroTitle: "अपने अधिकार जानें। खुद को सुरक्षित रखें।",
    heroSubtitle: "अपनी स्थिति का सरल भाषा में वर्णन करें, और हमारा AI आपको आपके कानूनी अधिकारों और उठाए जा सकने वाले कदमों को समझने में मदद करेगा।",
    inputPlaceholder: "उदाहरण: मेरे मकान मालिक मेरे घर खाली करने के बाद सिक्योरिटी डिपॉजिट वापस करने से मना कर रहे हैं...",
    analyzeButton: "मेरी स्थिति का विश्लेषण करें",
    analyzing: "विश्लेषण कर रहा है...",
    categoryTitle: "कानूनी श्रेणी",
    explanationTitle: "सरल स्पष्टीकरण",
    stepsTitle: "उठाए जाने वाले कदम",
    commonCategories: "सामान्य कानूनी मुद्दे",
    localHelp: "स्थानीय कानूनी सहायता खोजें",
    localHelpDesc: "आपके क्षेत्र में मुफ्त और कम लागत वाले कानूनी क्लीनिक उपलब्ध हैं।",
    consumerRights: "उपभोक्ता अधिकार",
    workerRights: "श्रमिक अधिकार",
    womensRights: "महिलाओं के अधिकार",
    tenantRights: "किरायेदार के अधिकार",
    digitalFraud: "डिजिटल धोखाधड़ी",
    footerText: "एक नागरिक प्रौद्योगिकी पहल। औपचारिक कानूनी सलाह नहीं।",
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("en");

  const t = (key: keyof typeof translations["en"]) => {
    return translations[language][key];
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
