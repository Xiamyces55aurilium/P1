import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, type AnalyzeInput, type AnalyzeResponse } from "@shared/routes";
import { z } from "zod";

function parseWithLogging<T>(schema: z.ZodSchema<T>, data: unknown, label: string): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    console.error(`[Zod] ${label} validation failed:`, result.error.format());
    throw result.error;
  }
  return result.data;
}

export function useAnalyzeQuery() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: AnalyzeInput): Promise<AnalyzeResponse> => {
      const validatedInput = api.queries.analyze.input.parse(data);
      
      const res = await fetch(api.queries.analyze.path, {
        method: api.queries.analyze.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validatedInput),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.queries.analyze.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to analyze query");
      }
      
      const responseData = await res.json();
      return parseWithLogging(api.queries.analyze.responses[200], responseData, "analyze.response");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.queries.list.path] });
    }
  });
}

export function useListQueries() {
  return useQuery({
    queryKey: [api.queries.list.path],
    queryFn: async () => {
      const res = await fetch(api.queries.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch queries");
      
      const data = await res.json();
      return parseWithLogging(api.queries.list.responses[200], data, "queries.list");
    },
  });
}
