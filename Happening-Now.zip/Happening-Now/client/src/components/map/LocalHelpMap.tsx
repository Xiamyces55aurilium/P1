import { MapPin, Navigation } from "lucide-react";
import { useLanguage } from "@/lib/LanguageContext";

export default function LocalHelpMap() {
  const { t } = useLanguage();

  return (
    <section className="py-16 bg-primary text-primary-foreground">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          
          <div className="flex-1 text-center lg:text-left">
            <div className="inline-flex items-center justify-center p-3 rounded-2xl bg-accent/20 text-accent mb-6">
              <MapPin className="w-8 h-8" />
            </div>
            <h2 className="text-3xl sm:text-4xl font-display font-bold text-white mb-4">
              {t("localHelp")}
            </h2>
            <p className="text-xl text-primary-foreground/80 mb-8 max-w-xl mx-auto lg:mx-0">
              {t("localHelpDesc")}
            </p>
            <button className="px-8 py-4 rounded-xl font-bold bg-accent text-accent-foreground shadow-lg hover:bg-accent/90 hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 flex items-center gap-2 mx-auto lg:mx-0">
              <Navigation className="w-5 h-5" />
              Find Near Me
            </button>
          </div>

          <div className="flex-1 w-full relative">
            {/* Elegant Map Container */}
            <div className="rounded-3xl overflow-hidden shadow-2xl shadow-black/40 border-4 border-white/10 relative h-[400px] w-full bg-slate-100">
              {/* Privacy-friendly OpenStreetMap iframe */}
              <iframe 
                width="100%" 
                height="100%" 
                frameBorder="0" 
                scrolling="no" 
                marginHeight={0} 
                marginWidth={0} 
                src="https://www.openstreetmap.org/export/embed.html?bbox=77.1000%2C28.5000%2C77.3000%2C28.7000&amp;layer=mapnik&amp;marker=28.6139%2C77.2090"
                className="absolute inset-0 grayscale contrast-75 opacity-90"
                style={{ filter: "hue-rotate(210deg) saturate(30%) brightness(90%)" }}
                title="Local Legal Aid Clinics"
              ></iframe>
              
              {/* Overlay Gradient to make it match the theme */}
              <div className="absolute inset-0 bg-primary/20 pointer-events-none mix-blend-multiply"></div>
              
              {/* Floating Fake Pin for Design */}
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center pointer-events-none">
                <div className="bg-accent text-accent-foreground px-4 py-2 rounded-lg shadow-lg font-bold text-sm mb-2 animate-bounce">
                  Legal Clinic
                </div>
                <div className="w-4 h-4 bg-accent rotate-45 transform origin-bottom -mt-3 shadow-sm"></div>
                <div className="w-8 h-2 bg-black/20 rounded-full blur-sm mt-1"></div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </section>
  );
}
