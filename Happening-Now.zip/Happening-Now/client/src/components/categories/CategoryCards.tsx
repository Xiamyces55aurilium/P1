import { ShoppingCart, HardHat, Shield, Home, Smartphone, ChevronDown } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "@/lib/LanguageContext";
import { motion, AnimatePresence } from "framer-motion";

export default function CategoryCards() {
  const { t } = useLanguage();
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const categories = [
    {
      id: "consumer",
      title: t("consumerRights"),
      icon: <ShoppingCart className="w-6 h-6" />,
      color: "bg-blue-500",
      description: "Protection against unfair trade practices, defective goods, and deficiency in services. You have the right to safety, information, choice, and redressal."
    },
    {
      id: "worker",
      title: t("workerRights"),
      icon: <HardHat className="w-6 h-6" />,
      color: "bg-amber-500",
      description: "Ensures fair wages, safe working conditions, and protection from unlawful termination. Covers minimum wage laws and workplace harassment."
    },
    {
      id: "womens",
      title: t("womensRights"),
      icon: <Shield className="w-6 h-6" />,
      color: "bg-rose-500",
      description: "Protection against domestic violence, workplace harassment, and right to equal pay and property inheritance."
    },
    {
      id: "tenant",
      title: t("tenantRights"),
      icon: <Home className="w-6 h-6" />,
      color: "bg-emerald-500",
      description: "Protection from unlawful eviction, right to essential services (water, electricity), and rules regarding security deposits and rent increases."
    },
    {
      id: "digital",
      title: t("digitalFraud"),
      icon: <Smartphone className="w-6 h-6" />,
      color: "bg-purple-500",
      description: "Recourse for financial cyber fraud, identity theft, and unauthorized transactions. Time is critical: report immediately to your bank and cyber cell."
    },
  ];

  return (
    <section className="py-16 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <h2 className="text-3xl sm:text-4xl font-display font-bold text-primary mb-4">
          {t("commonCategories")}
        </h2>
        <div className="w-24 h-1.5 bg-accent mx-auto rounded-full"></div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map((cat) => {
          const isExpanded = expandedId === cat.id;
          return (
            <motion.div
              layout
              key={cat.id}
              className="bg-card rounded-2xl shadow-lg shadow-black/5 border border-border/50 overflow-hidden hover:shadow-xl hover:border-primary/20 transition-all duration-300"
            >
              <button
                onClick={() => setExpandedId(isExpanded ? null : cat.id)}
                className="w-full text-left p-6 flex items-center justify-between"
              >
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-white shadow-md ${cat.color}`}>
                    {cat.icon}
                  </div>
                  <h3 className="text-lg font-bold text-foreground">{cat.title}</h3>
                </div>
                <motion.div
                  animate={{ rotate: isExpanded ? 180 : 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <ChevronDown className="w-5 h-5 text-muted-foreground" />
                </motion.div>
              </button>

              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="px-6 pb-6 pt-0 border-t border-border/50 mt-2">
                      <p className="text-muted-foreground pt-4 leading-relaxed">
                        {cat.description}
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
