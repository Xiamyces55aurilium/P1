import { Scale, Globe } from "lucide-react";
import { useLanguage } from "@/lib/LanguageContext";

export default function Navbar() {
  const { language, setLanguage, t } = useLanguage();

  return (
    <header className="sticky top-0 z-50 w-full backdrop-blur-xl bg-background/80 border-b border-border/50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center shadow-lg shadow-primary/20">
            <Scale className="w-6 h-6 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-bold text-primary tracking-tight hidden sm:block">
            {t("appName")}
          </h1>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={() => setLanguage(language === "en" ? "hi" : "en")}
            className="flex items-center gap-2 px-4 py-2 rounded-full border-2 border-border/60 hover:border-primary hover:bg-primary/5 transition-all duration-200 font-semibold text-sm"
          >
            <Globe className="w-4 h-4 text-primary" />
            <span className="text-foreground uppercase tracking-wider">{language}</span>
          </button>
        </div>
      </div>
    </header>
  );
}
