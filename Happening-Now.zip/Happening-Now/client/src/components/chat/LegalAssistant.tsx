import { useState } from "react";
import { Send, AlertCircle, CheckCircle2, ChevronRight, ShieldAlert, FileText, Loader2 } from "lucide-react";
import { useLanguage } from "@/lib/LanguageContext";
import { useAnalyzeQuery } from "@/hooks/use-queries";
import { motion, AnimatePresence } from "framer-motion";

export default function LegalAssistant() {
  const { language, t } = useLanguage();
  const [queryText, setQueryText] = useState("");
  const analyzeMutation = useAnalyzeQuery();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!queryText.trim() || analyzeMutation.isPending) return;
    
    analyzeMutation.mutate({
      queryText,
      language,
    });
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card rounded-3xl p-6 sm:p-8"
      >
        <form onSubmit={handleSubmit} className="relative">
          <label htmlFor="query" className="sr-only">
            {t("inputPlaceholder")}
          </label>
          <div className="relative rounded-2xl shadow-sm overflow-hidden bg-background border-2 border-border focus-within:border-primary focus-within:ring-4 focus-within:ring-primary/10 transition-all duration-300">
            <textarea
              id="query"
              rows={4}
              className="block w-full resize-none border-0 bg-transparent py-4 px-5 text-foreground placeholder:text-muted-foreground focus:ring-0 sm:text-lg sm:leading-relaxed"
              placeholder={t("inputPlaceholder")}
              value={queryText}
              onChange={(e) => setQueryText(e.target.value)}
              disabled={analyzeMutation.isPending}
            />
            
            <div className="bg-muted/50 px-4 py-3 flex justify-between items-center border-t border-border">
              <div className="flex items-center text-xs text-muted-foreground gap-2">
                <ShieldAlert className="w-4 h-4" />
                <span className="hidden sm:inline">Your data is kept private and secure.</span>
              </div>
              <button
                type="submit"
                disabled={!queryText.trim() || analyzeMutation.isPending}
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold bg-primary text-primary-foreground shadow-md hover:bg-primary/90 hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:translate-y-0 transition-all duration-200"
              >
                {analyzeMutation.isPending ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>{t("analyzing")}</span>
                  </>
                ) : (
                  <>
                    <span>{t("analyzeButton")}</span>
                    <Send className="w-4 h-4 ml-1" />
                  </>
                )}
              </button>
            </div>
          </div>
        </form>

        {analyzeMutation.isError && (
          <div className="mt-6 p-4 rounded-xl bg-destructive/10 border border-destructive/20 flex items-start gap-3 text-destructive">
            <AlertCircle className="w-6 h-6 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-semibold">Error analyzing request</h4>
              <p className="text-sm mt-1 opacity-90">{analyzeMutation.error.message}</p>
            </div>
          </div>
        )}

        <AnimatePresence>
          {analyzeMutation.isSuccess && analyzeMutation.data && (
            <motion.div 
              initial={{ opacity: 0, height: 0, y: 20 }}
              animate={{ opacity: 1, height: "auto", y: 0 }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.4, ease: "easeOut" }}
              className="mt-8 space-y-6"
            >
              <div className="flex items-center gap-4 border-b border-border pb-4">
                <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center shrink-0">
                  <FileText className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold tracking-wider text-muted-foreground uppercase">
                    {t("categoryTitle")}
                  </h3>
                  <p className="text-2xl font-display text-primary mt-1">
                    {analyzeMutation.data.aiCategory || "General Legal Issue"}
                  </p>
                </div>
              </div>

              <div className="bg-secondary/40 rounded-2xl p-6 border border-border">
                <h3 className="text-lg font-bold text-foreground flex items-center gap-2 mb-3">
                  <AlertCircle className="w-5 h-5 text-accent" />
                  {t("explanationTitle")}
                </h3>
                <p className="text-foreground/80 leading-relaxed text-lg">
                  {analyzeMutation.data.aiExplanation}
                </p>
              </div>

              <div>
                <h3 className="text-lg font-bold text-foreground flex items-center gap-2 mb-4">
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                  {t("stepsTitle")}
                </h3>
                <ul className="space-y-3">
                  {analyzeMutation.data.aiSteps && analyzeMutation.data.aiSteps.length > 0 ? (
                    analyzeMutation.data.aiSteps.map((step, idx) => (
                      <motion.li 
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.1 * idx }}
                        key={idx} 
                        className="flex gap-4 p-4 rounded-xl hover:bg-muted transition-colors border border-transparent hover:border-border"
                      >
                        <span className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground font-bold flex items-center justify-center shadow-sm">
                          {idx + 1}
                        </span>
                        <p className="text-foreground/90 mt-1">{step}</p>
                      </motion.li>
                    ))
                  ) : (
                    <li className="text-muted-foreground italic">No specific steps recommended. Please consult local authorities.</li>
                  )}
                </ul>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
