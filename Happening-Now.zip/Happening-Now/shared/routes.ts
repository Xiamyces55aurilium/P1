import { z } from "zod";
import { insertLegalQuerySchema, legalQueries } from "./schema";

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  queries: {
    analyze: {
      method: "POST" as const,
      path: "/api/queries/analyze" as const,
      input: insertLegalQuerySchema,
      responses: {
        200: z.custom<typeof legalQueries.$inferSelect>(),
        400: errorSchemas.validation,
        500: errorSchemas.internal,
      },
    },
    list: {
      method: "GET" as const,
      path: "/api/queries" as const,
      responses: {
        200: z.array(z.custom<typeof legalQueries.$inferSelect>()),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type AnalyzeInput = z.infer<typeof api.queries.analyze.input>;
export type AnalyzeResponse = z.infer<typeof api.queries.analyze.responses[200]>;
